/**
 * Author: Sanika Tamhankar
 * BannerID: B00909848
 * Email: sn295037@dal.ca
 */
export const myData = [
  {
    address: "1991 Brunswick St, B3J2GJ, Canada",

    account: "285 425",

    risk_appetite: "High",

    addr_ip: "address",

    accountNum_ip: "account number",

    risk_app_ip: "risk appetite",

    not_provided: "Not Provided",
  },
];
