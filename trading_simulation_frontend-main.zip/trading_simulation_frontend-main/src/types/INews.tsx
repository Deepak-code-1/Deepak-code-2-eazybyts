/**

 * Author: Prakrut Suthar

 * BannerID: B00885349

 * Email:prakrut@dal.ca

*/

export interface INews {
  userID: String;
  newsID: String;
  news_topic: String;
  news_content: String;
}
