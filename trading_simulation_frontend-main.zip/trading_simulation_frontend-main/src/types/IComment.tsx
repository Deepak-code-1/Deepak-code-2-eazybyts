export interface IComment {
  userID: String;
  symbol: String;
  commentID: String;
  comment: String;
  creation_date: String;
}
